<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use App\Models\{
    Phase
};

class Task extends Model
{

    protected $fillable = [
        'name',
        'phase_id',
        'user_id',
        'completed_at'
    ];

    use HasFactory;

    protected static function boot()
    {
        parent::boot();

        static::updating(function ($task) {
            // Get the previous (original) value of 'phase_id'
            $previousPhaseId = $task->getOriginal('phase_id');

            

            // Get the previous (original) value of 'completed_at'
            $previousCompletedAt = $task->getOriginal('completed_at');


            // Get the new value of 'phase_id'
            $newPhaseId = $task->phase_id;

            $newPhase = Phase::find($newPhaseId);
            if (
                !empty($newPhase->name) && // verify New Phase Name not empty
                ($newPhase->name == "completion") && // Verify New Phase is completion
                ($previousPhaseId != $newPhaseId) && // Verify Phase is updating
                empty($previousCompletedAt) // Verify completed_at only updated once
            ) {
                $task->completed_at = Carbon::now();
            }
        });
    }

    function user()
    {
        return $this->belongsTo(User::class);
    }

    function phase()
    {
        return $this->belongsTo(Phase::class);
    }
}
